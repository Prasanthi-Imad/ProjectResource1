package com.cg.emp.dao;

import com.cg.emp.bean.Employee;

public interface IempDao {
	
	public boolean store(Employee emp);

	
}
