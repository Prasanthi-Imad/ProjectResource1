package com.capg.emp.exception;

public class EmployeeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	EmployeeException() {

	}

	public EmployeeException(String args0) {
		super(args0);
	}

}
