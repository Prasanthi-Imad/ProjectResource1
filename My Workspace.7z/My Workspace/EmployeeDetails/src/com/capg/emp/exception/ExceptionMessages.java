package com.capg.emp.exception;

public class ExceptionMessages {
	public static final String ERROR2 = "ID must be minimum of 4 characters";
	public static final String ERROR3 = "Salary must be greater than 1000";
	public static final String ERROR4 = " Fill the department details";
	public static String ERROR1 = "Name must be minimum of 4 characters";
}
